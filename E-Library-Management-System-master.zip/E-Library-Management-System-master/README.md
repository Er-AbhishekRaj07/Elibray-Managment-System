# E-Library Management System
This is a mock E-Library management based Web Project. <strong>Entity framework</strong> was used for database management.
<p>
<strong>Topics covered:</strong>
<ul>
  <li>ASP.NET WebForms based application</li>
  <li>SQL Server</li>
  <li>Entity Framework</li>
  <li>Bootstrap</li>
</ul>
</p>
Change <strong>connectionStrings</strong> xml in <strong>Web.config</strong> file and connect to your own database before using it.
<p><strong><br/>Practice</strong></p>

